/*
 *  Copyright (c) 2012, Lenny <leonardo.masoni@gmail.com>
 *  All rights reserved.
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <stdlib.h>

#include "reverb.h"

typedef struct {
    int32_t *bs, *be, *bp;
    int32_t sm;
} bf_t;

typedef struct {
    bf_t comb[8];
    bf_t allpass[4];
} ch_t;

static ch_t ch[2];

static int comb_lengths[] = {1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617};
static int allpass_lengths[] = {225, 341, 441, 556};
static int stereo_adjust = 12;

static void reverb_bf_alloc(bf_t *bf, int len) {

    bf->bp = bf->bs = calloc(len, sizeof(int32_t));
    bf->be = bf->bs + len;
    bf->sm = 0;
}

static void reverb_bf_advance(bf_t *bf) {

    bf->bp++;

    if (bf->bp == bf->be)
        bf->bp = bf->bs;
}

static void reverb_bf_free(bf_t *bf) {

    free(bf->bs);
}

static int32_t comb_process(bf_t *bf, int32_t input) {

    int32_t output = *bf->bp;
    bf->sm = (output + bf->sm) >> 1; // damp
    *bf->bp = input + ((bf->sm * 15) >> 4); // feedback

    reverb_bf_advance(bf);

    return output;
}

static int32_t allpass_process(bf_t *bf, int32_t input) {

    int32_t output = *bf->bp;
    *bf->bp = input + (output >> 1);

    reverb_bf_advance(bf);

    return output - input;
}

void reverb_init(void) {

    int i;

    for (i = 0; i < 2; i++) {

        int j;

        for (j = 0; j < 8; j++)
            reverb_bf_alloc(
                ch[i].comb + j,
                comb_lengths[j] + stereo_adjust * i);

        for (j = 0; j < 4; j++)
            reverb_bf_alloc(
                ch[i].allpass + j,
                allpass_lengths[j] + stereo_adjust * i);
    }
}

void reverb_render(int32_t *buf, int len) {

    int i;

    for (i = 0; i < 2; i++) {

        int32_t *bp = buf + i;
        int k;

        for (k = len; k; k--) {

            int32_t a = *bp;
            int32_t b = 0;

            int j;

            for (j = 0; j < 8; j++)
                b += comb_process(ch[i].comb + j, a);

            for (j = 0; j < 4; j++)
                b = allpass_process(ch[i].allpass + j, b);

            *bp = a + (b >> 7);
            bp += 2;
        }
    }
}

void reverb_free(void) {

    int i;

    for (i = 0; i < 2; i++) {

        int j;

        for (j = 0; j < 8; j++)
            reverb_bf_free(ch[i].comb + j);

        for (j = 0; j < 4; j++)
            reverb_bf_free(ch[i].allpass + j);
    }
}
