#ifndef ALSA_SEQ_H
#define ALSA_SEQ_H

void seq_init(void);
void seq_free(void);

void seq_read(void);

#endif
