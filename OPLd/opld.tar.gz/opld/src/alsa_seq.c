/*
 *  Copyright (c) 2012, Lenny <leonardo.masoni@gmail.com>
 *  All rights reserved.
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <stdlib.h>
#include <stdbool.h>

#include <alsa/asoundlib.h>

#include "main.h"
#include "alsa_seq.h"
#include "opl_midi.h"

static snd_seq_t *alsa_handle;
static int port;

void seq_init(void) {

    int err = snd_seq_open(&alsa_handle,
                           seq_name, SND_SEQ_OPEN_INPUT,
                           SND_SEQ_NONBLOCK);

    if (err < 0) {
        printf("snd_seq_open failed: %s\n",
               snd_strerror(err));
        exit(EXIT_FAILURE);
    }

    snd_seq_set_client_name(alsa_handle, app_name);

    port = snd_seq_create_simple_port(
               alsa_handle, app_name,
               SND_SEQ_PORT_CAP_WRITE | SND_SEQ_PORT_CAP_SUBS_WRITE,
               SND_SEQ_PORT_TYPE_MIDI_GENERIC);

    midi_init();
}

void seq_read(void) {

    snd_seq_event_t *ev = NULL;

    while (snd_seq_event_input(alsa_handle, &ev) >= 0) {

        switch (ev->type) {

        case SND_SEQ_EVENT_NOTEON:
            midi_note_on(
                ev->data.note.channel,
                ev->data.note.note,
                ev->data.note.velocity);
            break;

        case SND_SEQ_EVENT_NOTEOFF:
            midi_note_off(
                ev->data.note.channel,
                ev->data.note.note);
            break;

        case SND_SEQ_EVENT_CONTROLLER:
            midi_controller(
                ev->data.control.channel,
                ev->data.control.param,
                ev->data.control.value);
            break;

        case SND_SEQ_EVENT_PGMCHANGE:
            midi_program(
                ev->data.control.channel,
                ev->data.control.value);
            break;

        case SND_SEQ_EVENT_PITCHBEND:
            midi_pitch_bend(
                ev->data.control.channel,
                ev->data.control.value);
            break;
        }

        snd_seq_free_event(ev);
    }
}

void seq_free(void) {

    snd_seq_delete_simple_port(alsa_handle, port);
    snd_seq_close(alsa_handle);

    midi_free();
}
