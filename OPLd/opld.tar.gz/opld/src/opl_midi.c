/*
 *  Copyright (c) 2012, Lenny <leonardo.masoni@gmail.com>
 *  All rights reserved.
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <stdlib.h>
#include <limits.h>

#include "opl_sw.h"
#include "opl_midi.h"
#include "alsa_pcm.h"

typedef struct {
    int patch; // current sound
    int vol; // vol controller
    int pan; // pan position
    int bend; // pitch bend position
} midi_channel_t;

typedef struct {
    int channel; // MIDI channel
    int note; // note (-1 = off)
    uint32_t time; // when it was started or stopped
} midi_voice_t;

static uint32_t render_tick; // counter for killing notes

static midi_voice_t midi_voice[ADLIB_CHANNELS]; // synth voice status
static midi_channel_t midi_channel[MIDI_CHANNELS]; // MIDI channel info

void midi_pitch_bend(int channel, int bend) {

    int i;

    for (i = 0; i < ADLIB_CHANNELS; i++) {
        if ((midi_voice[i].channel == channel) &&
                (midi_voice[i].note > -1)) {
            fm_set_pitch(i, midi_voice[i].note, bend);
        }
    }

    midi_channel[channel].bend = bend;
}

static int get_voice() {

    int best_voice = -1;
    uint32_t best_tick = UINT32_MAX;

    int i;

    // Look for a free voice

    for (i = 0; i < ADLIB_CHANNELS; i++) {
        if ((midi_voice[i].note < 0) &&
                (midi_voice[i].time < best_tick) &&
                ((i < fm_xmin) || (i > fm_xmax))) {
            best_voice = i;
            best_tick = midi_voice[i].time;
        }
    }

    if (best_voice < 0) {

        // All voices are busy

        for (i = 0; i < ADLIB_CHANNELS; i++) {
            if ((midi_voice[i].time < best_tick) &&
                    ((i < fm_xmin) || (i > fm_xmax))) {
                best_voice = i;
                best_tick = midi_voice[i].time;
            }
        }

        midi_note_off(
            midi_voice[best_voice].channel,
            midi_voice[best_voice].note);
    }

    return best_voice;
}

void midi_note_on(int channel, int note, int vel) {

    vel = vel * midi_channel[channel].vol / 127;

    if (channel == 9) {

        fm_drum_on(note, vel);

    } else {

        midi_note_off(channel, note);

        int voice = get_voice();

        midi_voice[voice].channel = channel;
        midi_voice[voice].note = note;
        midi_voice[voice].time = render_tick;

        fm_set_instr(voice, midi_channel[channel].patch);
        fm_set_pitch(voice, note, midi_channel[channel].bend);
        fm_set_pan(voice, midi_channel[channel].pan);
        fm_note_on(voice, vel);
    }
}

void midi_note_off(int channel, int note) {

    int i;

    for (i = 0; i < ADLIB_CHANNELS; i++) {
        if (((midi_voice[i].channel == channel) || (channel < 0)) &&
                ((midi_voice[i].note == note) || (note < 0))) {

            fm_note_off(i);

            midi_voice[i].channel = -1;
            midi_voice[i].note = -1;
            midi_voice[i].time = render_tick;
        }
    }
}

static void midi_reset_controllers(int channel) {

    midi_channel[channel].vol = 127;
    midi_channel[channel].bend = 0;
    midi_channel[channel].pan = 63;
}

void midi_program(int channel, int patch) {

    midi_channel[channel].patch = patch;
}

void midi_controller(int channel, int ctrl, int data) {

    switch (ctrl) {

    case 7: /* channel volume */
        midi_channel[channel].vol = data;
        break;

    case 10: /* pan */
        midi_channel[channel].pan = data;
        break;

    case 120: /* all sound off */
        midi_note_off(channel, -1);
        break;

    case 121: /* reset all controllers */
        midi_reset_controllers(channel);
        break;

    default:
        break;
    }
}

void midi_init(void) {

    int i;

    fm_init();
    fm_set_drum_mode(true);

    for (i = 0; i < MIDI_CHANNELS; i++) {
        midi_reset_controllers(i);
    }

    for (i = 0; i < ADLIB_CHANNELS; i++) {
        midi_voice[i].channel = -1;
        midi_voice[i].note = -1;
    }
}

void midi_render(void) {
    fm_render(pcm_buf, pcm_cur);
    render_tick++;
}

void midi_free(void) {
    fm_free();
}
