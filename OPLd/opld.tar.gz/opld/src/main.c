/*
 *  Copyright (c) 2012, Lenny <leonardo.masoni@gmail.com>
 *  All rights reserved.
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <signal.h>
#include <sys/time.h>

#include "main.h"
#include "alsa_pcm.h"
#include "alsa_seq.h"
#include "opl_midi.h"

char *app_name = "opld";
char *seq_name = "default";
char *pcm_name = "default";

static volatile bool running = true;

static void termination_handler(int signum) {
    running = false;
}

static void alarm_handler(int signum) {

    seq_read();
    midi_render();
    pcm_write();

    pcm_cur += (snd_pcm_avail(alsa_handle) - (int)alsa_buffer_size / 2) >> 7;

    if (pcm_cur < pcm_len / 2)
        pcm_cur = pcm_len / 2;
    else if (pcm_cur > pcm_len)
        pcm_cur = pcm_len;
}

static void interval_setup(int msec) {

    if (signal(SIGALRM, msec > 0 ? alarm_handler : SIG_DFL) == SIG_ERR)
        perror("signal");

    struct itimerval tv = {
        {0, msec * 1000},
        {0, msec * 1000}
    };

    if (setitimer(ITIMER_REAL, &tv, NULL) < 0)
        perror("setitimer");
}

int main(int argc, char *argv[]) {

    int i;

    while ((i = getopt(argc, argv, "f:")) != -1) {

        switch (i) {

        case 'f':
            break;
        }
    }

    seq_init();
    pcm_init();

    interval_setup(1000 / SAMPLE_FPS);

    if (signal(SIGINT, termination_handler) == SIG_ERR)
        perror("signal");

    while (running)
        pause();

    if (signal(SIGALRM, SIG_DFL) == SIG_ERR)
        perror("signal");

    interval_setup(0);

    seq_free();
    pcm_free();

    return EXIT_SUCCESS;
}
