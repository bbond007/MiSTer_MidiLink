#ifndef ALSA_PCM_H
#define ALSA_PCM_H

#include <stdint.h>
#include <alsa/asoundlib.h>

extern snd_pcm_t *alsa_handle;
extern snd_pcm_uframes_t alsa_buffer_size, alsa_period_size;

extern int32_t *pcm_buf;
extern int pcm_cur, pcm_len;

void pcm_init(void);
void pcm_free(void);

void pcm_write(void);

#endif
