#ifndef OPL_SW_H
#define OPL_SW_H

#include <stdint.h>
#include <stdbool.h>

#define ADLIB_CHANNELS 18
#define ADLIB_OPERATORS (ADLIB_CHANNELS * 2)

extern int fm_xmin, fm_xmax;

void fm_init(void);
void fm_free(void);

void fm_set_drum_mode(bool);

void fm_note_on(int, int);
void fm_note_off(int);

void fm_drum_on(int, int);

void fm_set_pitch(int, int, int);
void fm_set_instr(int, int);
void fm_set_pan(int, int);

void fm_render(int32_t *, int);

#endif
