#ifndef OPL_MIDI_H
#define OPL_MIDI_H

#include <stdint.h>

#define MIDI_CHANNELS 16

void midi_init(void);
void midi_free(void);

void midi_note_on(int, int, int);
void midi_note_off(int, int);

void midi_controller(int, int, int);
void midi_program(int, int);
void midi_pitch_bend(int, int);

void midi_render(void);

#endif
