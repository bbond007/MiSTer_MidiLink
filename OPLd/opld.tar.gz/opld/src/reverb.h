#ifndef REVERB_H
#define REVERB_H

#include <stdint.h>

void reverb_init(void);
void reverb_free(void);

void reverb_render(int32_t *, int);

#endif
