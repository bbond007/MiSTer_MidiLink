/*
 *  Copyright (c) 2012, Lenny <leonardo.masoni@gmail.com>
 *  All rights reserved.
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "main.h"
#include "opl_sw.h"
#include "ymf262.h"
#include "fm_instr.h"

int fm_xmin = -1, fm_xmax = -1;

static int fm_20_offset[] = {
    0x000, 0x001, 0x002, 0x008, 0x009, 0x00A, 0x010, 0x011, 0x012,
    0x100, 0x101, 0x102, 0x108, 0x109, 0x10A, 0x110, 0x111, 0x112,
};

static int fm_A0_offset[] = {
    0x000, 0x001, 0x002, 0x003, 0x004, 0x005, 0x006, 0x007, 0x008,
    0x100, 0x101, 0x102, 0x103, 0x104, 0x105, 0x106, 0x107, 0x108,
};

// From the ymf278 datasheet

static int fm_note_fnum[] = {
    346, // C  - 261.6 hz
    367, // C# - 277.2 hz
    389, // D  - 293.7 hz
    412, // D# - 311.1 hz
    436, // E  - 329.6 hz
    462, // F  - 349.2 hz
    490, // F# - 370.0 hz
    519, // G  - 392.0 hz
    550, // G# - 415.3 hz
    582, // A  - 440.0 hz
    617, // A# - 466.2 hz
    654, // B  - 493.9 hz
    693, // C  - 523.3 hz
};

// Square law midi velocity

static int fm_vel_tl[] = {
    63, 55, 48, 43, 40, 37, 35, 34,
    32, 31, 29, 28, 27, 26, 26, 25,
    24, 23, 23, 22, 21, 21, 20, 20,
    19, 19, 18, 18, 18, 17, 17, 16,
    16, 16, 15, 15, 15, 14, 14, 14,
    13, 13, 13, 13, 12, 12, 12, 12,
    11, 11, 11, 11, 10, 10, 10, 10,
    9, 9, 9, 9, 9, 8, 8, 8,
    8, 8, 8, 7, 7, 7, 7, 7,
    7, 6, 6, 6, 6, 6, 6, 5,
    5, 5, 5, 5, 5, 5, 5, 4,
    4, 4, 4, 4, 4, 4, 3, 3,
    3, 3, 3, 3, 3, 3, 3, 2,
    2, 2, 2, 2, 2, 2, 2, 2,
    1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 0, 0, 0, 0, 0, 0,
};

static void *chip;
static int fm_drum_mask;
static fm_instr_t *op_inst[ADLIB_CHANNELS][2];
static int op_B0[ADLIB_CHANNELS];

static void A0_set(int voice, fm_instr_t *inst) {

    int oct = inst->note / 12 - 1;
    int note = inst->note % 12;

    int freq = fm_note_fnum[note];
    int offset = fm_A0_offset[voice];

    opl3_write(chip, 0xA0 + offset, freq & 0xFF);
    opl3_write(chip, 0xB0 + offset, (oct << 2) | (freq >> 8));
    opl3_write(chip, 0xC0 + offset, inst->feedback_conn);
}

static int kl_vol(int kl, int vel) {

    int att = (kl & 0x3F) + fm_vel_tl[vel];

    if (att > 63)
        att = 63;

    return (kl & 0xC0) | att;
}

static void fm_set_inst_op1(int voice, fm_instr_t *inst) {

    if (op_inst[voice][0] == inst)
        return;

    int offset = fm_20_offset[voice];

    opl3_write(chip, 0x20 + offset, inst->am_vib_1);
    opl3_write(chip, 0x60 + offset, inst->attack_decay_1);
    opl3_write(chip, 0x80 + offset, inst->sustain_release_1);
    opl3_write(chip, 0xE0 + offset, inst->wave_select_1);

    op_inst[voice][0] = inst;
}

static void fm_set_inst_op2(int voice, fm_instr_t *inst) {

    if (op_inst[voice][1] == inst)
        return;

    int offset = fm_20_offset[voice];

    opl3_write(chip, 0x23 + offset, inst->am_vib_2);
    opl3_write(chip, 0x63 + offset, inst->attack_decay_2);
    opl3_write(chip, 0x83 + offset, inst->sustain_release_2);
    opl3_write(chip, 0xE3 + offset, inst->wave_select_2);

    op_inst[voice][1] = inst;
}

void fm_set_instr(int voice, int patch) {

    fm_instr_t *inst = fm_melodic + patch;

    fm_set_inst_op1(voice, inst);
    fm_set_inst_op2(voice, inst);
}

void fm_init(void) {

    chip = opl3_init(14320000, SAMPLE_RATE);

    opl3_write(chip, 0x105, 0x01); // enable OPL3 mode
}

void fm_set_drum_mode(bool usedrums) {

    if (usedrums) {

        fm_drum_mask = 0x20;
        fm_xmin = 6;
        fm_xmax = 8;

        fm_set_inst_op1(7, fm_drum + 7); // Closed Hi-Hat
        fm_set_inst_op2(7, fm_drum + 3); // Acoustic Snare
        fm_set_inst_op1(8, fm_drum + 10); // Low Tom
        fm_set_inst_op2(8, fm_drum + 14); // Crash Cymbal 1

        A0_set(7, fm_drum + 3); // Acoustic Snare
        A0_set(8, fm_drum + 10); // Low Tom

    } else {

        fm_drum_mask = 0;
        fm_xmin = -1;
        fm_xmax = -1;
    }

    opl3_write(chip, 0xBD, fm_drum_mask);
}

void fm_drum_on(int note, int vel) {

    note -= 35;

    if (note < 0)
        return;

    if (note > 46)
        return;

    fm_instr_t *inst = fm_drum + note;

    switch (inst->type) {

    case FM_BD:

        fm_set_inst_op1(6, inst);
        opl3_write(chip, 0x40 + fm_20_offset[6],
                   inst->ksl_level_1);

        fm_set_inst_op2(6, inst);
        opl3_write(chip, 0x43 + fm_20_offset[6],
                   kl_vol(inst->ksl_level_2, vel));

        A0_set(6, inst);
        break;

    case FM_SD:

        fm_set_inst_op2(7, inst);
        opl3_write(chip, 0x43 + fm_20_offset[7],
                   kl_vol(inst->ksl_level_2, vel));

        A0_set(7, inst);
        break;

    case FM_TT:

        fm_set_inst_op1(8, inst);
        opl3_write(chip, 0x40 + fm_20_offset[8],
                   kl_vol(inst->ksl_level_1, vel));

        A0_set(8, inst);
        break;

    case FM_CY:

        fm_set_inst_op2(8, inst);
        opl3_write(chip, 0x43 + fm_20_offset[8],
                   kl_vol(inst->ksl_level_2, vel));

        break;

    case FM_HH:

        fm_set_inst_op1(7, inst);
        opl3_write(chip, 0x40 + fm_20_offset[7],
                   kl_vol(inst->ksl_level_1, vel));

        break;

    default:
        break;
    }

    int bit = 1 << inst->type;

    fm_drum_mask &= ~bit;
    opl3_write(chip, 0xBD, fm_drum_mask);

    fm_drum_mask |= bit;
    opl3_write(chip, 0xBD, fm_drum_mask);
}

void fm_note_on(int voice, int vel) {

    if (op_inst[voice][0]->feedback_conn & 0x01) {

        opl3_write(chip, 0x40 + fm_20_offset[voice],
                   kl_vol(op_inst[voice][0]->ksl_level_1, vel));

    } else {

        opl3_write(chip, 0x40 + fm_20_offset[voice],
                   op_inst[voice][0]->ksl_level_1);
    }

    opl3_write(chip, 0x43 + fm_20_offset[voice],
               kl_vol(op_inst[voice][1]->ksl_level_2, vel));

    op_B0[voice] |= 0x20;
    opl3_write(chip, 0xB0 + fm_A0_offset[voice], op_B0[voice]);
}

void fm_note_off(int voice) {

    op_B0[voice] &= 0xDF;
    opl3_write(chip, 0xB0 + fm_A0_offset[voice], op_B0[voice]);
}

void fm_set_pan(int voice, int pan) {

    if (pan < 48) {
        pan = 0x10;
    } else if (pan >= 80) {
        pan = 0x20;
    } else {
        pan = 0x30;
    }

    opl3_write(chip, 0xC0 + fm_A0_offset[voice],
               pan | op_inst[voice][0]->feedback_conn);
}

void fm_set_pitch(int voice, int note, int bend) {

    note += op_inst[voice][0]->note - 12;

    if (note < 0)
        note = 0;

    if (note > 95)
        note = 95;

    int oct = note / 12;
    note %= 12;

    int freq = fm_note_fnum[note];
    int offset = fm_A0_offset[voice];

    // Pitch bend
    freq = freq + (fm_note_fnum[note + 1] - freq) * bend / 0x1000;

    opl3_write(chip, 0xA0 + offset, freq & 0xFF);

    // Preserve KON bit
    op_B0[voice] &= 0x20;
    op_B0[voice] |= (oct << 2) | (freq >> 8);

    opl3_write(chip, 0xB0 + offset, op_B0[voice]);
}

void fm_render(int32_t *buf, int len) {
    opl3_render(chip, buf, len);
}

void fm_free(void) {
    opl3_free(chip);
}
