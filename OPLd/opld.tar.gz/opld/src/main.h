#ifndef MAIN_H
#define MAIN_H

#define SAMPLE_RATE (48000)
#define SAMPLE_FPS (100)

extern char *app_name;
extern char *seq_name;
extern char *pcm_name;

#endif
