#ifndef YMF262_H
#define YMF262_H

#include <stdint.h>

void *opl3_init(int, int);
void opl3_free(void *);

void opl3_write(void *, int, uint8_t);
void opl3_render(void *, int32_t *, int);

#endif
