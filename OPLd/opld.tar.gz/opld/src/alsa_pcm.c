/*
 *  Copyright (c) 2012, Lenny <leonardo.masoni@gmail.com>
 *  All rights reserved.
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <stdlib.h>

#include "main.h"
#include "alsa_pcm.h"
#include "reverb.h"

snd_pcm_t *alsa_handle;
snd_pcm_uframes_t alsa_buffer_size, alsa_period_size;

int32_t *pcm_buf;
int pcm_cur, pcm_len;

void pcm_init(void) {

    int err;

    err = snd_pcm_open(&alsa_handle,
                       pcm_name, SND_PCM_STREAM_PLAYBACK, 0);

    if (err < 0) {
        printf("snd_pcm_open failed: %s\n",
               snd_strerror(err));
        exit(EXIT_FAILURE);
    }

    err = snd_pcm_set_params(
              alsa_handle, SND_PCM_FORMAT_S16_LE,
              SND_PCM_ACCESS_RW_INTERLEAVED,
              2, SAMPLE_RATE, 1, 100000);

    if (err < 0) {
        printf("snd_pcm_set_params failed: %s\n",
               snd_strerror(err));
        exit(EXIT_FAILURE);
    }

    err = snd_pcm_get_params(alsa_handle, &alsa_buffer_size, &alsa_period_size);

    if (err < 0) {
        printf("snd_pcm_get_params failed: %s\n",
               snd_strerror(err));
        exit(EXIT_FAILURE);
    }

    pcm_cur = SAMPLE_RATE / SAMPLE_FPS;
    pcm_len = pcm_cur * 2;
    pcm_buf = (int32_t *)calloc(pcm_len * 2, sizeof (int32_t));

    reverb_init();
}

void pcm_write(void) {

    reverb_render(pcm_buf, pcm_cur);

    {
        // Convert from int32_t samples to int16_t samples

        int32_t *a = pcm_buf;
        int16_t *b = (int16_t *) pcm_buf;

        int i;

        for (i = pcm_cur * 2; i; i--, a++, b++) {

            int32_t t = *a;

            if (t < -INT16_MAX)
                *b = -INT16_MAX;
            else if (t > INT16_MAX)
                *b = INT16_MAX;
            else
                *b = t;
        }
    }

    {
        // Output to sound card

        int err = snd_pcm_writei(alsa_handle, pcm_buf, pcm_cur);

        if (err < 0) {
            err = snd_pcm_recover(alsa_handle, err, 0);
        }

        if (err < 0) {
            printf("snd_pcm_recover failed: %s\n",
                   snd_strerror(err));
            exit(EXIT_FAILURE);
        }
    }
}

void pcm_free(void) {

    reverb_free();

    snd_pcm_close(alsa_handle);
    free(pcm_buf);
}
